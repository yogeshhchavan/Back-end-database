-- MySQL schema for Zumba Enrollment System
CREATE DATABASE IF NOT EXISTS zumba_db;
USE zumba_db;

CREATE TABLE IF NOT EXISTS batches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_name VARCHAR(50) NOT NULL,
  timing VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  batch_id INT NULL,
  CONSTRAINT fk_students_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL
);

-- Sample seed data
INSERT INTO batches (batch_name, timing) VALUES
('Morning Batch A', '07:00 - 08:00'),
('Evening Batch A', '18:00 - 19:00');
