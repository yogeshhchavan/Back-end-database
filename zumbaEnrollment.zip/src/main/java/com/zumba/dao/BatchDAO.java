package com.zumba.dao;

import com.zumba.model.Batch;
import com.zumba.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BatchDAO {

    public void create(Batch b) throws SQLException {
        String sql = "INSERT INTO batches (batch_name, timing) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, b.getBatchName());
            ps.setString(2, b.getTiming());
            ps.executeUpdate();
        }
    }

    public List<Batch> listAll() throws SQLException {
        String sql = "SELECT id, batch_name, timing FROM batches ORDER BY id DESC";
        List<Batch> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Batch b = new Batch(
                        rs.getInt("id"),
                        rs.getString("batch_name"),
                        rs.getString("timing")
                );
                list.add(b);
            }
        }
        return list;
    }

    public Batch findById(int id) throws SQLException {
        String sql = "SELECT id, batch_name, timing FROM batches WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Batch(
                            rs.getInt("id"),
                            rs.getString("batch_name"),
                            rs.getString("timing")
                    );
                }
            }
        }
        return null;
    }

    public void update(Batch b) throws SQLException {
        String sql = "UPDATE batches SET batch_name=?, timing=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, b.getBatchName());
            ps.setString(2, b.getTiming());
            ps.setInt(3, b.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM batches WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
