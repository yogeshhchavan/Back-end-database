package com.zumba.dao;

import com.zumba.model.Student;
import com.zumba.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public void create(Student s) throws SQLException {
        String sql = "INSERT INTO students (name, email, phone, batch_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getPhone());
            if (s.getBatchId() == null) ps.setNull(4, Types.INTEGER);
            else ps.setInt(4, s.getBatchId());
            ps.executeUpdate();
        }
    }

    public List<Student> listAll() throws SQLException {
        String sql = "SELECT id, name, email, phone, batch_id FROM students ORDER BY id DESC";
        List<Student> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Student s = new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        (Integer) rs.getObject("batch_id")
                );
                list.add(s);
            }
        }
        return list;
    }

    public Student findById(int id) throws SQLException {
        String sql = "SELECT id, name, email, phone, batch_id FROM students WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Student(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getString("phone"),
                            (Integer) rs.getObject("batch_id")
                    );
                }
            }
        }
        return null;
    }

    public void update(Student s) throws SQLException {
        String sql = "UPDATE students SET name=?, email=?, phone=?, batch_id=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getPhone());
            if (s.getBatchId() == null) ps.setNull(4, Types.INTEGER);
            else ps.setInt(4, s.getBatchId());
            ps.setInt(5, s.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM students WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
