package com.zumba.model;

public class Batch {
    private int id;
    private String batchName;
    private String timing; // e.g., Morning / Evening or "07:00 - 08:00"

    public Batch() {}

    public Batch(int id, String batchName, String timing) {
        this.id = id;
        this.batchName = batchName;
        this.timing = timing;
    }

    public Batch(String batchName, String timing) {
        this.batchName = batchName;
        this.timing = timing;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getBatchName() { return batchName; }
    public void setBatchName(String batchName) { this.batchName = batchName; }

    public String getTiming() { return timing; }
    public void setTiming(String timing) { this.timing = timing; }
}
