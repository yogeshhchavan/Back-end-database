package com.zumba.servlet;

import com.zumba.dao.BatchDAO;
import com.zumba.model.Batch;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name="BatchServlet", urlPatterns={"/batches"})
public class BatchServlet extends HttpServlet {

    private final BatchDAO batchDAO = new BatchDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if (action == null || action.equals("list")) {
                List<Batch> batches = batchDAO.listAll();
                req.setAttribute("batches", batches);
                req.getRequestDispatcher("/batch/listBatches.jsp").forward(req, resp);
            } else if (action.equals("new")) {
                req.getRequestDispatcher("/batch/addBatch.jsp").forward(req, resp);
            } else if (action.equals("edit")) {
                int id = Integer.parseInt(req.getParameter("id"));
                Batch b = batchDAO.findById(id);
                req.setAttribute("batch", b);
                req.getRequestDispatcher("/batch/updateBatch.jsp").forward(req, resp);
            } else if (action.equals("delete")) {
                int id = Integer.parseInt(req.getParameter("id"));
                batchDAO.delete(id);
                resp.sendRedirect(req.getContextPath() + "/batches?action=list");
            } else {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown action");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("create".equals(action)) {
                Batch b = new Batch();
                b.setBatchName(req.getParameter("batchName"));
                b.setTiming(req.getParameter("timing"));
                batchDAO.create(b);
                resp.sendRedirect(req.getContextPath() + "/batches?action=list");
            } else if ("update".equals(action)) {
                Batch b = new Batch();
                b.setId(Integer.parseInt(req.getParameter("id")));
                b.setBatchName(req.getParameter("batchName"));
                b.setTiming(req.getParameter("timing"));
                batchDAO.update(b);
                resp.sendRedirect(req.getContextPath() + "/batches?action=list");
            } else {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown action");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
