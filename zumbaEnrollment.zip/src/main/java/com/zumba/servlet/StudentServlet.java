package com.zumba.servlet;

import com.zumba.dao.StudentDAO;
import com.zumba.dao.BatchDAO;
import com.zumba.model.Student;
import com.zumba.model.Batch;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name="StudentServlet", urlPatterns={"/students"})
public class StudentServlet extends HttpServlet {

    private final StudentDAO studentDAO = new StudentDAO();
    private final BatchDAO batchDAO = new BatchDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if (action == null || action.equals("list")) {
                List<Student> students = studentDAO.listAll();
                req.setAttribute("students", students);
                req.getRequestDispatcher("/student/listStudents.jsp").forward(req, resp);
            } else if (action.equals("new")) {
                req.setAttribute("batches", batchDAO.listAll());
                req.getRequestDispatcher("/student/addStudent.jsp").forward(req, resp);
            } else if (action.equals("edit")) {
                int id = Integer.parseInt(req.getParameter("id"));
                Student s = studentDAO.findById(id);
                req.setAttribute("student", s);
                req.setAttribute("batches", batchDAO.listAll());
                req.getRequestDispatcher("/student/updateStudent.jsp").forward(req, resp);
            } else if (action.equals("delete")) {
                int id = Integer.parseInt(req.getParameter("id"));
                studentDAO.delete(id);
                resp.sendRedirect(req.getContextPath() + "/students?action=list");
            } else {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown action");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("create".equals(action)) {
                Student s = new Student();
                s.setName(req.getParameter("name"));
                s.setEmail(req.getParameter("email"));
                s.setPhone(req.getParameter("phone"));
                String batchIdStr = req.getParameter("batchId");
                if (batchIdStr == null || batchIdStr.isEmpty()) s.setBatchId(null);
                else s.setBatchId(Integer.parseInt(batchIdStr));
                studentDAO.create(s);
                resp.sendRedirect(req.getContextPath() + "/students?action=list");
            } else if ("update".equals(action)) {
                Student s = new Student();
                s.setId(Integer.parseInt(req.getParameter("id")));
                s.setName(req.getParameter("name"));
                s.setEmail(req.getParameter("email"));
                s.setPhone(req.getParameter("phone"));
                String batchIdStr = req.getParameter("batchId");
                if (batchIdStr == null || batchIdStr.isEmpty()) s.setBatchId(null);
                else s.setBatchId(Integer.parseInt(batchIdStr));
                studentDAO.update(s);
                resp.sendRedirect(req.getContextPath() + "/students?action=list");
            } else {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown action");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
