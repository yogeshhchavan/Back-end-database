package com.zumba.util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class DBInitListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        String url = sce.getServletContext().getInitParameter("DB_URL");
        String user = sce.getServletContext().getInitParameter("DB_USER");
        String password = sce.getServletContext().getInitParameter("DB_PASSWORD");
        DBConnection.configure(url, user, password);
        System.out.println("DB configured: " + url);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL Driver not found", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // nothing to clean
    }
}
